export default function CauaSite() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900">
      {/* Header */}
      <header className="text-center py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <img
              src="/caua-avatar.png"
              alt="Avatar do Cauã"
              className="w-32 h-32 rounded-full mx-auto mb-6 border-4 border-blue-400 shadow-2xl object-cover"
            />
            <h1 className="text-6xl font-bold text-white mb-4">CAUÃ HENRIQUE</h1>
            <p className="text-2xl text-purple-200 mb-8">🎮 Criador de Roblox Roleplay • 📺 YouTuber • 🎵 TikToker</p>
          </div>
        </div>
      </header>

      {/* Links das Redes Sociais */}
      <main className="px-4 pb-20">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-white text-center mb-12">🔗 Minhas Redes Sociais</h2>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {/* YouTube */}
            <a
              href="https://www.youtube.com/@CauaHenrique-lt3zf"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-red-600 rounded-2xl p-8 text-center hover:bg-red-700 transition-all duration-300 transform hover:scale-105 cursor-pointer block"
            >
              <div className="text-6xl mb-4">📺</div>
              <h3 className="text-2xl font-bold text-white mb-4">YouTube</h3>
              <p className="text-red-100 mb-6">Criando Roblox Roleplay</p>
              <div className="text-white">
                <p className="text-sm">📊 10 Inscritos</p>
                <p className="text-sm">🎬 39 Vídeos</p>
                <p className="text-sm">🎮 Roleplay Content</p>
              </div>
            </a>

            {/* Roblox */}
            <a
              href="https://www.roblox.com/pt/users/3772312400/profile"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-green-600 rounded-2xl p-8 text-center hover:bg-green-700 transition-all duration-300 transform hover:scale-105 cursor-pointer block"
            >
              <div className="text-6xl mb-4">🎮</div>
              <h3 className="text-2xl font-bold text-white mb-4">Roblox</h3>
              <p className="text-green-100 mb-6">Meu perfil e jogos</p>
              <div className="text-white">
                <p className="text-sm">👤 ID: 3772312400</p>
                <p className="text-sm">🎯 Roleplay Expert</p>
                <p className="text-sm">🏆 Active Player</p>
              </div>
            </a>

            {/* TikTok */}
            <a
              href="https://www.tiktok.com/@cauazinho_blox779"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-pink-600 rounded-2xl p-8 text-center hover:bg-pink-700 transition-all duration-300 transform hover:scale-105 cursor-pointer block"
            >
              <div className="text-6xl mb-4">🎵</div>
              <h3 className="text-2xl font-bold text-white mb-4">TikTok</h3>
              <p className="text-pink-100 mb-6">@cauazinho_blox779</p>
              <div className="text-white">
                <p className="text-sm">🎬 Roblox Content</p>
                <p className="text-sm">⚡ Quick Videos</p>
                <p className="text-sm">🔥 Gaming Tips</p>
              </div>
            </a>
          </div>

          {/* Conteúdo Recente */}
          <h2 className="text-4xl font-bold text-white text-center mb-12">🔥 Meus Vídeos Recentes</h2>

          <div className="grid md:grid-cols-3 gap-6 mb-16">
            <div className="bg-white/10 rounded-xl overflow-hidden hover:bg-white/20 transition-all duration-300">
              <img
                src="/placeholder.svg?height=200&width=300&text=🎮 Roleplay"
                alt="VEM PRA CRIANDO ROBLOX ROLEPLAY"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-white font-bold mb-2">VEM PRA CRIANDO ROBLOX ROLEPLAY</h3>
                <p className="text-gray-300 text-sm mb-3">Convite especial para o meu servidor de roleplay!</p>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>YouTube</span>
                  <span>🎬 Roleplay</span>
                </div>
              </div>
            </div>

            <div className="bg-white/10 rounded-xl overflow-hidden hover:bg-white/20 transition-all duration-300">
              <img
                src="/placeholder.svg?height=200&width=300&text=🤠 Cowboy"
                alt="SKIN VERSÃO COWBOY"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-white font-bold mb-2">SKIN VERSÃO COWBOY AMIGOS</h3>
                <p className="text-gray-300 text-sm mb-3">Mostrando minha nova skin de cowboy no Roblox!</p>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>YouTube</span>
                  <span>👕 Skins</span>
                </div>
              </div>
            </div>

            <div className="bg-white/10 rounded-xl overflow-hidden hover:bg-white/20 transition-all duration-300">
              <img
                src="/placeholder.svg?height=200&width=300&text=🍎 Frutas"
                alt="DOANDO FRUTAS"
                className="w-full h-48 object-cover"
              />
              <div className="p-4">
                <h3 className="text-white font-bold mb-2">DOANDO FRUTAS PARA INICIANTES</h3>
                <p className="text-gray-300 text-sm mb-3">Ajudando novos jogadores com frutas grátis!</p>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>YouTube</span>
                  <span>🎁 Doação</span>
                </div>
              </div>
            </div>
          </div>

          {/* Seção especial com o avatar */}
          <div className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 rounded-2xl p-8 mb-16 text-center border border-blue-400/30">
            <div className="flex flex-col md:flex-row items-center justify-center gap-8">
              <img
                src="/caua-avatar.png"
                alt="Avatar do Cauã no Roblox"
                className="w-24 h-24 rounded-full border-4 border-blue-400 shadow-xl"
              />
              <div>
                <h3 className="text-2xl font-bold text-white mb-2">Meu Avatar no Roblox</h3>
                <p className="text-blue-200 mb-4">
                  Esse é meu personagem principal! Cabelo loiro, estilo único e sempre pronto para os melhores
                  roleplays!
                </p>
                <a
                  href="https://www.roblox.com/pt/users/3772312400/profile"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded-full transition-colors"
                >
                  Ver meu perfil completo
                </a>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="bg-white/10 rounded-2xl p-8 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">Vamos jogar juntos! 🤝</h2>
            <p className="text-gray-300 mb-8 text-lg">
              Me segue nas redes sociais e vem participar dos meus roleplays no Roblox!
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="https://www.youtube.com/@CauaHenrique-lt3zf"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-full transition-colors"
              >
                📺 YouTube
              </a>
              <a
                href="https://www.roblox.com/pt/users/3772312400/profile"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-full transition-colors"
              >
                🎮 Roblox
              </a>
              <a
                href="https://www.tiktok.com/@cauazinho_blox779"
                target="_blank"
                rel="noopener noreferrer"
                className="bg-pink-600 hover:bg-pink-700 text-white font-bold py-3 px-6 rounded-full transition-colors"
              >
                🎵 TikTok
              </a>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
